package ShoesManager.GUI;

import ShoesManager.DTO.*;

/**
 * Lưu trữ cách biến dự liệu cơ bản
 */
public class Memory {
    //Tai khoan
    static String maNV;
    static int iCapBac;
    
    //NHan vien
    static NhanVienDTO nhanvien;

    // color
    static java.awt.Color colorThemes;
    static java.awt.Color colorThemes_2;
    static java.awt.Color colorText;
    
    // an hien menu
    static boolean flag_Menu;
    
    // quesion yes or no
    static boolean yesno_Q;
    
    // sản phẩm
    static String maSP;
    
    // link file
    static String filechoose;
}
